package com.impact.backend.entity;

public class UnmatchedCalls{

    Integer unmatchedCalls;

    public UnmatchedCalls(Integer unmatchedCalls) {
        this.unmatchedCalls = unmatchedCalls;
    }

    public Integer getUnmatchedCalls() {
        return unmatchedCalls;
    }

    public void setUnmatchedCalls(Integer unmatchedCalls) {
        this.unmatchedCalls = unmatchedCalls;
    }
}